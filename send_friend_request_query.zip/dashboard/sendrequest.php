<?php
include('session.php');


       if(isset($_POST['request'])){

            echo $reguesed_id = $_POST['request'];
		    $Query = "INSERT INTO  friends (`m_id_one`,`m_id_two`,`status`) VALUES ('$user_id','$reguesed_id','Panding')";
		    $res = mysqli_query($conn,$Query);

		}

		else{}
		
?>


     <?php


   if(isset($_POST['requestdata'])){

   	$user_id = $_POST['userid'];

         $Query = "SELECT users.userId , users.image , users.userName,users.address,users.class , friends.m_id_one , friends.m_id_two FROM users 
                    LEFT JOIN  `kidsbook_kidsbook`.`friends` ON  `users`.`userId` =  `friends`.`m_id_two` OR `users`.`userId` = `friends`.`m_id_one`
                    WHERE users.userId NOT IN (SELECT friends.m_id_one  FROM friends WHERE friends.m_id_two = '$user_id') 
                    AND users.userId NOT IN (SELECT friends.m_id_two  FROM friends WHERE friends.m_id_one = '$user_id')
                    AND users.userId <> '$user_id'";
                  
                   

                // $qou = "select * from friends where m_id_one ='$user_id'";
                   $qou="SELECT  `users`.`userId` ,  `users`.`userName` ,`users`.`image`, `friends`.`f_id` , `friends`.`m_id_two` ,
                `friends`.`m_id_one` , `friends`.`status` 
                  FROM users
                  LEFT JOIN  `kidsbook_kidsbook`.`friends` ON  `users`.`userId` =  `friends`.`m_id_two` OR `users`.`userId` = `friends`.`m_id_one`
                   WHERE  `friends`.`m_id_one` = '$user_id'"; 

                     $myfriends = mysqli_query($conn,$qou);
                     while($rowq=mysqli_fetch_array($myfriends)){

                     
                    $status =  $rowq['status'];
                    $my_id =  $rowq['m_id_one'];
                    $request_id =  $rowq['userId'];

                   if($request_id == $user_id)
                   {
                    echo "";
                   }

                      else if($status == "Panding"){ ?>
                       
                       <div class="row"  style="background-color:#f5f5f5; padding:5px; border-bottom: 1px solid #e7e7e7; padding:10px;margin-bottom:5px;">
                            <div class="col-sm-2" style="border:px solid;">
                              <img style="border-radius:50px; width:40px; height:40px;" src="<?php echo $rowq['image']; ?>" alt="Picture">
                            </div><!--end of col-sm-2-->
                            <div class="col-sm-4" style="border:px solid;">
                              
                             <p style="top:10px;"><?php echo $rowq['userName']; ?></p>
                               
                            </div><!--end of col-sm-8-->
                            <div class="col-sm-6" style="border:px solid;">
                              
                              
                      <button type="submit"  class="btn btn-warning btn-xs" value="<?php  ?>">Send Request</button>
            

                            </div><!--end of col-sm-2-->

                          </div><!--end of row--> 

                   <?php } } ?>


                    <?php
                         $rs = mysqli_query($conn,$Query);    
                     while($user = mysqli_fetch_array($rs)){
                        
                        $sender_id =  $user['userId'];
                        $user_id = $_POST['userid'];

                       ?>


                        <?php  $user['userId']; ?>
                          
                          <div class="row"  style="background-color:#f5f5f5; padding:5px; border-bottom: 1px solid #e7e7e7; padding:10px;margin-bottom:5px;">
                            <div class="col-sm-2" style="border:px solid;">
                              <img style="border-radius:50px; width:40px; height:40px;" src="<?php echo $user['image']; ?>" alt="Picture">
                            </div><!--end of col-sm-2-->
                            <div class="col-sm-4" style="border:px solid;">
                              
                             <p style="top:10px;"><?php echo $user['userName']; ?></p>
                               
                            </div><!--end of col-sm-8-->
                            <div class="col-sm-6" style="border:px solid;">
                              
                              
                      <button type="submit" id="send_id<?php echo $sender_id; ?>" class="btn btn-primary btn-xs send-btn" value="<?php echo $sender_id; ?>">Add Friend</button>
            

                            </div><!--end of col-sm-2-->

                          </div><!--end of row--> 

                          <?php  } ?>


         


                          <?php  } ?>


