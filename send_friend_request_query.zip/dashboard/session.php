<?php

    ob_start();
  session_start();
  
$conn=mysqli_connect('localhost','root','','kidsbook_kidsbook');
  
  // if session is not set this will redirect to login page
  if( !isset($_SESSION['user']) ) {
    echo "<script>location='../index.php'</script>";
    exit;
  }
  $em=$_SESSION['user'];
  // select loggedin users detail
  $res=mysqli_query($conn,"SELECT * FROM users WHERE userId=$em");
  $userRow=mysqli_fetch_array($res);
  $username = $userRow['userName'];  
  $user_id = $userRow['userId'];


?>