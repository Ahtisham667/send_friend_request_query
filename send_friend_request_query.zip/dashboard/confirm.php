<?php

include('session.php');

  $friend_id = $_GET['confirm'];




		if($friend_id !="")
		{
			$query = mysqli_query($conn,"UPDATE friends SET status='Accept' WHERE f_id='$friend_id'");
		    // $Query = "INSERT INTO  friends (`m_id_one`,`m_id_two`,`status`) VALUES ('$logined_id','$reguesed_id','Panding')";
		    // $res = mysqli_query($conn,$Query);
		}
		else
		{
			echo "SomeThink Error";
		}
?>


