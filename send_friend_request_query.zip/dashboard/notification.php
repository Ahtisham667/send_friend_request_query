<?php
                            include('session.php');
                            $userId = $_GET['userId'];
                            $query = "SELECT COUNT(*)As c FROM friends where m_id_two='$userId' and status ='Panding'";
                            $result = mysqli_query($conn,$query);
                            $row = mysqli_fetch_assoc($result);

                            echo $row['c'];

?>