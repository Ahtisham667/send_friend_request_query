<?php include('session.php'); ?>
<?php

?>
<!doctype html>
<html>
  <link href="./assets/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
      <script src="./assets/js/bootstrap.min.js"></script>
      <script src="./assets/js/jquery.min.js"></script>
      <!------ Include the above in your HEAD tag ---------->

      <link href="./assets/css/boootstrap.min.css" rel="stylesheet" />   
      <link href="css/style.css" rel="stylesheet" />   
      <link rel="stylesheet" href="./assets/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">


      <!--tab script-->
      <script src="./assets/js/bootsstrap.min.js"></script>
      <script src="./assets/js/jquerys.min.js"></script>
      <!--end tabs script-->
      <script
        src="./assets/js/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

 <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <head>
        <title>Facebook Style Popup Design</title>




<!--           <div class="input-group" style="">
                        <label class="newbtn" >
                        <img src="images/file.png" style="margin-left:50x; width:25px; height:20px;" >
                        <input id="pic" hidden="" accept="image/*" type="file" id="imgfile" name="imgfile" onchange="loadFile(event)">
                        </label>
                       </div>
<input type="file" accept="image/*" onchange="loadFile(event)"> -->
<!-- <img id="output"/ style="width:50px;height:50px;border:1px solid white;"> --> 
<script>
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('output');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
</script>

</script>
<div class="container-fluid" style="background-color:#069;border-bottom:2px padding:10px; 5solid #999; height:72px;"><br>
<?php include('fine_friend.php'); ?>
</div>

<br><br>
<p id="btn"></p>
<div class="container">
  <div class="col-sm-5" id="">
   
   <p id="send_requestss"></p>
   <p id="friendss"></p>

  </div>
  <div class="col-sm-2"></div>
  <div class="col-sm-5">
  <p id="requestsendfriend"></p>
  </div>
</div>
         
      


    </body>
</html>

     

           <script>
   

                $(document).ready(function(){
                displayChat();
                // requestdatafetch();
                 $(document).on('click', '.send-btn', function(e){


                    var request = $('#'+e.currentTarget.id).val();
                     //alert(request);

                    $.ajax({
                      type: "POST",
                      url: "sendrequest.php",
                      data: {
                        request: request,
                        // sender: sender,
                      },
                      success: function(){
                        $('#send_requestss').val("");
                     displayChat();
                      }
                    });
                  
                });
                  
                
                 });

                function displayChat(){
                userid = <?php echo $user_id; ?>;
                $.ajax({
                  url: 'sendrequest.php',
                  type: 'POST',
                  async: false,
                  data:{
                    userid: userid,
                    requestdata: 1,
                  },
                  success: function(response){
                    $('#friendss').html(response);
                    //$("#chat_area").scrollTop($("#chat_area")[0].scrollHeight);
                  }
                });
                 }
                    


         </script>

           



