	

	



<?php

	// this will avoid mysql_connect() deprecation error.
$conn=mysqli_connect('localhost','root','','kidsbook_kidsbook');
	
	

	
	
	function selfie()
	{
		$conn=mysqli_connect('localhost','root','','kidsbook_kidsbook');
		if($conn)
		{
			$query="select * from selfie";
			$run=mysqli_query($conn,$query);
			while($result=mysqli_fetch_array($run))
				{
					echo'
					 <div class="w3-container w3-card-2 w3-white w3-round w3-margin-right w3-margin-left"><br>
        			<img src="'.$result['stimage'].'" alt="Avatar" class="w3-left w3-circle w3-margin-right" style="width:50px;height:50px">
        			<span class="w3-right w3-opacity">'.$result['ptime'].'</span>
        			<h4>'. $result['stname'].'</h4><br>
        			<hr class="w3-clear">
        			<img src="'.$result['pimage'] .'" style="width:100%" class="w3-margin-bottom">
        			<p>'.$result['ptext'].'</p> 
      				</div>
					<br>
					';
				}
			
		}
	}
	
	function uploads()
	{
		$conn=mysqli_connect('localhost','root','','kidsbook_kidsbook');
		if($conn)
		{
			$query="select * from post";
			$run=mysqli_query($conn,$query);
			while($result=mysqli_fetch_array($run))
				{
					echo '
					<div class="w3-container w3-card-2 w3-white w3-round w3-margin-right w3-margin-left"><br>
        			<img src="images/'.$result['stimage'].'" alt="Avatar" class="w3-left w3-circle w3-margin-right" style="width:60px">
        			<span class="w3-right w3-opacity">'.$result['ptime'].'</span>
        			<h4>'. $result['stname'].'</h4><br>
        			<hr class="w3-clear">
        			<img src="images/'.$result['image'] .'" style="width:100%" class="w3-margin-bottom">
        			<p>'.$result['text'].'</p> 
      				</div>
					
					';
				}
			
		}
	}
	
	

	?>